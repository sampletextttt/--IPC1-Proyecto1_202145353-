    package Main;

import Ventana.vLogin;



public class Principal {

    public static void main(String[] args) {
        vLogin blogin=new vLogin();
        blogin.setVisible(true);
    }
    
}
