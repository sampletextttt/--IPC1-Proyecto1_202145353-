/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ventana;

/**
 *
 * @author William
 */
public class Curso {
    public String codigo;
    public String nombre;
    public String creditos;
    public String alumnos;
    public String profesor;

    public Curso(String codigo, String nombre, String creditos, String alumnos, String profesor) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.creditos = creditos;
        this.alumnos = alumnos;
        this.profesor = profesor;
    }
    
    
    
}
